package com.johnp.ho;

import java.util.Comparator;
import java.util.Map;

import static com.johnp.ho.constants.ApplicationConstants.DASH;

public class DataProcessor implements Comparator<String> {
	
    Map<String,String> base;
    
    //Takes in a base map to perform the comparison on.
    public DataProcessor(Map<String,String> base) {
        this.base = base;
    }

    /**
     * A Compare method that takes in the Keys of the Objects 
     * to compare 
     */
    public int compare(String a, String b) {
    	
    	//Perform the Difference on the First Mapped Value
        String firstValue = base.get(a);
        String[] firstValues = firstValue.split(DASH);
        int firstScoreDifference =  
        		Integer.parseInt(firstValues[0]) - Integer.parseInt(firstValues[1]);
        
        //Perform the Difference on the Second Mapped Value
        String secondValue = base.get(b);
        String[] secondValues = secondValue.split(DASH);
        int secondScoreDifference =  
        		Integer.parseInt(secondValues[0]) - Integer.parseInt(secondValues[1]);
        
        if (firstScoreDifference < secondScoreDifference) {
        	return -1; //Return back the first Object 
        } else {
        	return 1;  //Return back the second Object
        }
        
    }
}
