/**
 * 
 */
package com.johnp.ho;

import java.util.Map;
import java.util.TreeMap;

/**
 * This class is the main class for the Point Calculator
 * @author JohnP
 *
 */
public class PointsDifferenceCalculator implements IPointsDifferenceCalculator {

	public PointsDifferenceCalculator () {}
	
	/* (non-Javadoc)
	 * @see com.johnp.ho.IPointsDifferenceCalculator#getLeastCalculatedGoalDifference()
	 */
	@Override
	public Map<String,String> getLeastCalculatedGoalDifference () {
		
		//Processing the File Data to a Collection 
		IFileProcessor fileProcessor = new FileProcessor();
		Map<String, String> unsortedMap = fileProcessor.getMappedDataFromFile();

		//Processing the Unsorted Collection to Sorted Collection 
		DataProcessor dataProcessor = new DataProcessor(unsortedMap);
		TreeMap<String,String> sortedMap = new TreeMap<String,String>(dataProcessor);
		sortedMap.putAll(unsortedMap);
		return sortedMap;
		
	} 
		
	/**
	 * Main mehtod for this Application
	 * @param args
	 */
	public static void main(String[] args) {
		
		//Instantiate the Points Calculator and get the Points Difference 
		IPointsDifferenceCalculator calculator = new PointsDifferenceCalculator();
		TreeMap <String,String> calculatedMap = 
				(TreeMap <String,String>)calculator.getLeastCalculatedGoalDifference();
		System.out.println("The calculated map : " + calculatedMap);
		System.out.println("The Least performed Team: "+ calculatedMap.firstKey());
		System.out.println("The Least performed Score: "+ calculatedMap.firstEntry().getValue());
	}

}
