package com.johnp.ho;

import java.util.Map;

public interface IPointsDifferenceCalculator {

	/**
	 * This method calculated the Goal Difference 
	 * and sorts a collection of them in descending order. 
	 * @return Map of calculated values
	 */
	public abstract Map<String, String> getLeastCalculatedGoalDifference();

}