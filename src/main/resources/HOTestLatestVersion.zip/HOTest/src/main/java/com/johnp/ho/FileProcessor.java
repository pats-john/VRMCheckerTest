package com.johnp.ho;
import static com.johnp.ho.constants.ApplicationConstants.DOT;
import static com.johnp.ho.constants.ApplicationConstants.NEW_LINE_DEMARCATOR;
import static com.johnp.ho.constants.ApplicationConstants.PATH_TO_FILE;
import static com.johnp.ho.constants.ApplicationConstants.SPACE;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;


/**
 * This class focusses on getting the Data in the Input file and converting 
 * it to a working Collection for input data processing.  
 * @author JohnP
 *
 */
public class FileProcessor implements IFileProcessor {
	
	
	/* (non-Javadoc)
	 * @see com.johnp.ho.IFileProcessor#getMappedDataFromFile()
	 */
	@Override
	public Map<String,String> getMappedDataFromFile () {
		
		Reader inputFileReader = null;
		Map<String,String> returnMap = new HashMap<String,String>();
		
		//Read the Input File with Data into a Reader Object. 
		try {
			
			inputFileReader = this.openFile(PATH_TO_FILE);
			
		} catch (FileNotFoundException fileNotFoundException) {
			
			throw new RuntimeException("Error reading out the File");
		}
		
		//Initial and Read into a char array Buffer.
		char[] charSequence = new char[2 * 1024];
		try {
			inputFileReader.read(charSequence, 0, charSequence.length);
		} catch (Exception exception) {
			throw new RuntimeException("Error reading from inbound File");
		}
		
		//Tokenized for a New Line.
		StringTokenizer tokenizer = new StringTokenizer(
				new String(charSequence), NEW_LINE_DEMARCATOR);
		
		while (tokenizer.hasMoreTokens()) {//While there are more Lines

			String token = tokenizer.nextToken();
			if (token.contains(DOT)) {//Check if there is a DOT, denoting a valid line 
				
				//Split a line by the spaces in between the data items
				String [] values = token.split(SPACE);
				
				//Populate a Default Sorted Map using the Team Name as 
				//Key and the gor and against goals as Values  
				returnMap.put(values[1], values[6]+values[7]+values[8]);
			} 
		}
		return returnMap;
	}
	
	private FileReader openFile(String filename) throws FileNotFoundException {
		return new FileReader(new File(filename));
	}
}
