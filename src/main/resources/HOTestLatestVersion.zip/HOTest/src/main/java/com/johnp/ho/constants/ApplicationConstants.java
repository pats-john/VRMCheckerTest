package com.johnp.ho.constants;

public final class ApplicationConstants {

	private ApplicationConstants() {}
	
	public static final String PATH_TO_FILE = "src/test/resources/points-table";
	public static final String NEW_LINE_DEMARCATOR = "\n\r";
	public static final String SPACE = " ";
	public static final String DOT = ".";
	public static final String DASH = "-";
}
