package com.johnp.ho;

import java.util.Map;

public interface IFileProcessor {

	public abstract Map<String, String> getMappedDataFromFile();

}