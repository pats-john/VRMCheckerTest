package com.johnp.ho;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class TestFileProcessor {
	
	/**
	 * Test to test the Population of the File Data into the Data Collection. 
	 */
	@Test
	public void TestGetMappedDataFromFile () {
		IFileProcessor fileProcessor =  new FileProcessor();
		Map<String, String> map = fileProcessor.getMappedDataFromFile();
		assertEquals(20,map.size());
	}
}
