package com.johnp.ho;
import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Test;

public class TestDataProcessor {

	/**
	 * Test to test the sorting of the Data Processor. 
	 */
	@Test
	public void TestDataProcessorSort () {
		
		Map<String,String> basicMap = new HashMap<String,String>();
		basicMap.put("Arsenal", "15-1");
		basicMap.put("Chelsea", "16-6");
		basicMap.put("Man UTD", "14-3");
		
		DataProcessor dataProcessor = new DataProcessor(basicMap);
		TreeMap<String,String> sortedMap = new TreeMap<String,String>(dataProcessor);
		sortedMap.putAll(basicMap);
		assertEquals("Chelsea",sortedMap.firstEntry().getKey());
		assertEquals("16-6",sortedMap.firstEntry().getValue());
	}
}
